# Risk register and launch blockers: Appendix · Risk Note

Team: TEAM012 · Member: V V S S N Padmaji Saladi (2025mb26046) · Instructor: Vinaya Sathyanarayana

| **Risk**                               | **Likelihood** | **Impact** | **Control**                                                                                                   | **Owner**           |
|----------------------------------------|----------------|------------|---------------------------------------------------------------------------------------------------------------|---------------------|
| Incomplete or inconsistent NEX history | High           | Medium     | Data quality checks; minimum-history rule; pilot store chosen for data quality                                | Data & AI           |
| Wrong or invented answers              | Medium         | High       | Tool-only numbers; 100-question test set before launch; answer logging; launch blocker if any invented number | Product + Data & AI |
| Unfair scores for small vendors        | Medium         | High       | 8-delivery minimum; visible components; dispute path; score review by vendor size; no automated action        | Vendor Management   |
| Vendor data exposure                   | Low            | High       | Role-based access; scores hidden from associate role; data in retailer tenant                                 | Security            |
| Misuse of scores for penalties         | Medium         | High       | Policy: scores are evidence only; copilot refuses penalty questions; decisions by Vendor Management           | Merchandising       |
| Over-reliance on predictions           | Medium         | Medium     | Confidence and evidence on every answer; override with reason; training for leads                             | Store Operations    |
| Model drift (season, routes)           | High           | Medium     | Weekly retrain; per-vendor accuracy alerts; fallback to agreed window                                         | Data & AI           |
| Wrong change from vendor message       | Medium         | Medium     | Human confirmation required; low confidence cannot be confirmed                                               | Receiving lead      |
| LLM cost or latency growth             | Low            | Medium     | Batch predictions; small model; token caps; cost dashboard                                                    | Product             |

## Launch blockers

- Any invented number in the pre-launch test set.

- Arrival accuracy below the vendor-average baseline on real data.

- Evidence of systematic score bias against small vendors.

- No named owner for score review and disputes.
