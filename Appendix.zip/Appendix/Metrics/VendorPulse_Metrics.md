# Metrics and evaluation: Appendix · Metrics

Team: TEAM012 · Member: V V S S N Padmaji Saladi (2025mb26046) · Instructor: Vinaya Sathyanarayana

## Metric tree

Model metrics are tied to the business outcome they drive.

| **Business outcome**             | **Business metric**              | **Model / AI metric that drives it**    | **Pilot target**         |
|----------------------------------|----------------------------------|-----------------------------------------|--------------------------|
| Dock staffed when vendors arrive | Unstaffed arrivals per week      | % arrivals within ±45 min of prediction | −25% / ≥80%              |
| Less shrink from self-scans      | Vendor self-scan events per week | Precision of High-risk band             | −25% / High band ≥3x Low |
| Less idle receiving labor        | Hours waiting for vendors        | Reschedules ranked correctly (ROC-AUC)  | −25% / ≥70% (AUC ≥0.70)  |
| Trusted, adopted tool            | % mornings planned with tool     | Grounded-answer rate; invented numbers  | ≥70% / ≥90%, 0           |
| Fair vendor management           | Score disputes upheld            | Score stability; score by vendor size   | Monitor                  |

## Prototype results (simulated data)

![figure](model_vs_baseline.png)

Full numbers: Prototype/model/evaluation_results.json, reproduced by running the scripts in the Prototype folder.
