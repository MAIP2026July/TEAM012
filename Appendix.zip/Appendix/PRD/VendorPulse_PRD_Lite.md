# VendorPulse AI: Phase 1 MVP: Appendix · PRD-lite

Team: TEAM012 · Member: V V S S N Padmaji Saladi (2025mb26046) · Instructor: Vinaya Sathyanarayana

## 1. Context

Product: VendorPulse AI, a feature in the store associate app. Pilot: 1 store, 20-30 NEX vendors, 10 weeks. Owner: Product (DSD). Stakeholders: Store Operations, Receiving, Merchandising / Vendor Management, Inventory Control / Loss Prevention, Data & AI, Security.

## 2. Store roles and user stories

| **ID** | **As a…**           | **I want…**                                           | **Acceptance criteria**                                                                                                                |
|--------|---------------------|-------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|
| US1    | Receiving lead      | today's NEX vendors with predicted window and risk    | Sorted by predicted arrival; window, risk band, P(late), P(reschedule), confidence and 2-4 evidence lines per vendor; loads \<3 s      |
| US2    | Receiving lead      | to know when the system cannot predict                | Vendors with \<8 past deliveries show "Not enough data" and the agreed window; no score shown                                          |
| US3    | Receiving associate | to ask questions in plain English on a handheld       | Answers in ≤4 sentences; numbers only from tools; evidence + confidence shown; out-of-scope questions refused with owner named         |
| US4    | Receiving lead      | to confirm schedule changes the AI read from messages | Original text beside extracted fields; Confirm / Reject; low-confidence items cannot be confirmed, only escalated; every action logged |
| US5    | Receiving lead      | to override a prediction                              | Override with mandatory reason; shown on the card; logged for model review                                                             |
| US6    | Vendor manager      | a vendor's reliability score with evidence            | Score 0-100 with 4 components and delivery count; last-90-day history; visible to leads and Merchandising only                         |

## 3. Functional requirements

1.  Nightly batch: refresh features and predictions for the next 7 days per store.

2.  Risk bands: High if P(late or reschedule) ≥0.35, Medium ≥0.18, else Low (thresholds tuned in pilot).

3.  Confidence: High = 8+ same-weekday deliveries and stable arrival times; Medium = 5+; Low otherwise.

4.  Copilot tools: get_schedule, predict_arrival, predict_risk, get_vendor_score, get_vendor_history, extract_schedule_change.

5.  System prompt rules: answer only from tool results; say "not enough data" when tools return insufficient history; never compute or estimate numbers; refuse PO, item, chargeback, penalty and contract questions.

6.  Audit log for questions, tool calls, model version, overrides and confirmations.

## 4. Data assumptions

- 12+ months of receiving timestamps for the pilot store with vendor ID and status.

- Agreed delivery days and windows are maintained in the vendor master.

- Reschedules and no-shows can be derived from schedule vs receipt records (to be validated with receiving leads).

- Vendor messages reach a shared mailbox or dock-note field the system can read.

## 5. Fallback logic

| **Situation**                                      | **System behavior**                                              |
|----------------------------------------------------|------------------------------------------------------------------|
| Fewer than 8 past deliveries                       | No prediction or score; show agreed window and "not enough data" |
| Model or data refresh failed                       | Show agreed schedule with a banner "predictions unavailable"     |
| LLM unavailable or slow (\>5 s)                    | Show the schedule views; chat disabled with a message            |
| Extraction confidence Low or vendor not identified | No proposed change; send to receiving lead                       |
| Question out of scope                              | Refuse and name the owning team or roadmap phase                 |

## 6. Non-functional requirements

- Works on Zebra handhelds and desktop; answer latency under 3 s at P90.

- Role-based access; vendor scores hidden from associate role.

- Data stays in the retailer's Azure tenant; no vendor data used to train third-party models.

## 7. Out of scope (MVP)

Purchase orders, items, delivery variances, vendor penalties or chargebacks, automatic schedule changes, ASN/EDI vendors.
