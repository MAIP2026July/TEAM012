# Staged roadmap with proof gates: Appendix · Roadmap

Team: TEAM012 · Member: V V S S N Padmaji Saladi (2025mb26046) · Instructor: Vinaya Sathyanarayana

Each phase moves forward only when its proof gate is met. Dates assume seed funding in December 2026; first chain rollout from Q3 2027.

| **Phase**                  | **Timing**                                  | **Scope**                                                                               | **Learning goal**                              | **Proof gate**                                                                                                                                                                  |
|----------------------------|---------------------------------------------|-----------------------------------------------------------------------------------------|------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 0\. Prototype              | Done (Nov 2026)                             | Simulated data, ML models, copilot UI, HITL                                             | Is the workflow and trust model clear?         | Model beats agreed-window rule and vendor average on test data                                                                                                                  |
| 1\. Build MVP + paid pilot | Jan-Jun 2027 (12-week build, 10-week pilot) | 1 chain, up to 10 stores, real NEX history, handheld copilot, real LLM; \$25K pilot fee | Does it work on real data and do leads use it? | ≥80% arrivals within ±45 min; ≥40% of late or no-show deliveries planned for in advance; ≥90% grounded answers, 0 invented numbers; unstaffed arrivals and self-scans down ≥25% |
| 2\. Better predictions     | Q2 2027                                     | 5-10 stores; weather, traffic, holidays; proactive alerts                               | Does accuracy hold across store types?         | Accuracy holds; alert precision ≥60%; cost ≤\$3/store/day                                                                                                                       |
| 3\. Purchase orders        | H2 2027                                     | PO and expected items per delivery                                                      | Can PO data be trusted at delivery level?      | Answer accuracy ≥95%                                                                                                                                                            |
| 4\. Items and variances    | 2028                                        | Receiving data, digitized NEX invoices                                                  | Can variances be explained reliably?           | Validated by Inventory Control                                                                                                                                                  |
| 5\. Vendor performance     | 2028+                                       | Accuracy, shrink, chargebacks, drafted vendor letters                                   | Can this be governed fairly?                   | Governance sign-off; human approval on every vendor communication                                                                                                               |

## Rollback

At any phase the app can fall back to the plain agreed schedule with one configuration switch per store.
