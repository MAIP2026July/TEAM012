"""Step 3: inject app_data.json into template.html -> vendorpulse.html (one self-contained file)."""
from pathlib import Path
here = Path(__file__).resolve().parent
html = (here / "template.html").read_text().replace("/*__DATA__*/", (here / "app_data.json").read_text())
(here / "vendorpulse.html").write_text(html)
print("built", here / "vendorpulse.html")
