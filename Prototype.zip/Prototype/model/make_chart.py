"""Step 4 (optional): draw the model-vs-baseline chart used in the report and deck."""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = Path(__file__).resolve().parent
out = here.parent.parent / "Appendix" / "Metrics" / "model_vs_baseline.png"
m = json.loads((here / "evaluation_results.json").read_text())
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11})
ACC, MID, MUT = "#0f6e6a", "#6fa9a5", "#b9c7c5"
fig, axs = plt.subplots(1, 2, figsize=(11, 4.2))

a = m["arrival"]["within_45_min"]
vals = [a["agreed_window_rule"], a["vendor_recent_median"], a["ml_model"]]
ax = axs[0]
bars = ax.bar(["Agreed window\n(rule)", "Vendor recent\naverage", "ML model"], [v * 100 for v in vals], color=[MUT, MUT, ACC], width=0.55)
ax.axhline(80, color="#5b6866", ls="--", lw=1)
ax.text(2.35, 81.5, "Pilot target 80%", ha="right", fontsize=9, color="#5b6866")
ax.set_title("Arrivals within ±45 min of predicted time", fontsize=12, loc="left")
for b, v in zip(bars, vals):
    ax.text(b.get_x() + b.get_width() / 2, v * 100 + 1.5, f"{v*100:.0f}%", ha="center", fontsize=10)

r = m["high_risk_flag"]["band_actual_problem_rate"]
vals = [r["High"], r["Medium"], r["Low"]]
ax = axs[1]
bars = ax.bar(["High", "Medium", "Low"], [v * 100 for v in vals], color=[ACC, MID, MUT], width=0.55)
ax.set_title("Actually late or rescheduled, by risk band", fontsize=12, loc="left")
for b, v in zip(bars, vals):
    ax.text(b.get_x() + b.get_width() / 2, v * 100 + 1.5, f"{v*100:.0f}%", ha="center", fontsize=10)

for ax in axs:
    ax.set_ylim(0, 100); ax.set_ylabel("%")
    ax.spines[["top", "right"]].set_visible(False)
    ax.yaxis.grid(True, color="#e5e9e8"); ax.set_axisbelow(True)
fig.text(0.01, 0.01, "Simulated data. Time-based test set Jun 1 - Nov 5, 2026 (884 scheduled deliveries, 791 arrivals).", fontsize=9, color="#5b6866")
plt.tight_layout(rect=(0, 0.04, 1, 1))
plt.savefig(out, dpi=200)
print("saved", out)
