"""
VendorPulse AI - Step 1: Generate SIMULATED DSD delivery history for one pilot store.

Why simulated?  Real retailer data cannot be shared in a course submission.
The simulation reproduces the patterns we see in real NEX (no-ASN) vendor
deliveries: vendors arrive off their agreed window, some days are worse than
others, the holiday season adds delay, and some vendors reschedule or skip.

Output: data/deliveries.csv  (one row per scheduled delivery)
        data/vendors.csv     (vendor master)
"""
import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(42)
OUT = Path(__file__).resolve().parent.parent / "data"
OUT.mkdir(exist_ok=True)

START = pd.Timestamp("2025-05-01")
TODAY = pd.Timestamp("2026-11-06")          # "today" in the demo (a Friday)
DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

# --- Vendor master (fictional names) ---------------------------------------
# days = agreed delivery days (0=Mon); win = agreed window start hour
# profile drives behaviour: reliable / average / unreliable / erratic
VENDORS = [
    ("V101", "Lakeside Artisan Bakery",   "Bakery",     [0, 2, 4], 6,  "reliable"),
    ("V102", "Great Lakes Dairy Co-op",   "Dairy",      [0, 3],    7,  "average"),
    ("V103", "Kalamazoo Tortilla Works",  "Bakery",     [1, 4],    8,  "unreliable"),
    ("V104", "North Star Ice",            "Frozen",     [2, 5],    9,  "reliable"),
    ("V105", "Hometown Kettle Chips",     "Snacks",     [1],       10, "average"),
    ("V106", "Peninsula Craft Soda",      "Beverages",  [3],       11, "erratic"),
    ("V107", "Riverbend Farm Eggs",       "Dairy",      [0, 4],    7,  "average"),
    ("V108", "Sunrise Floral Supply",     "Floral",     [1, 4],    8,  "unreliable"),
    ("V109", "Mitten State Jerky",        "Snacks",     [2],       13, "reliable"),
    ("V110", "Old Mill Bread Co",         "Bakery",     [0, 2, 4], 6,  "average"),
    ("V111", "Thumb Area Produce",        "Produce",    [0, 3, 5], 7,  "erratic"),
    ("V112", "Copper Kettle Salsa",       "Deli",       [2],       10, "average"),
    ("V113", "Bay City Pierogi",          "Frozen",     [4],       12, "unreliable"),
    ("V114", "Grand River Kombucha",      "Beverages",  [1, 4],    11, "average"),
    ("V115", "Cherry Coast Preserves",    "Grocery",    [3],       9,  "reliable"),
    ("V116", "Saginaw Valley Honey",      "Grocery",    [4],       14, "average"),
    ("V117", "Westside Tamale Kitchen",   "Deli",       [1, 4],    10, "unreliable"),
    ("V118", "Ann Arbor Bagel House",     "Bakery",     [0, 3],    6,  "reliable"),
    ("V119", "Upper Peninsula Pasties",   "Frozen",     [2],       12, "erratic"),
    ("V120", "Holland Dutch Cookies",     "Snacks",     [3],       10, "average"),
    ("V121", "Lansing Popcorn Co",        "Snacks",     [1, 4],    13, "average"),
    ("V122", "Detroit Hot Sauce Lab",     "Grocery",    [2],       11, "unreliable"),
    ("V123", "Lake Effect Coffee Roasters","Beverages", [0, 4],    9,  "reliable"),
    ("V124", "Fresh Field Microgreens",   "Produce",    [1, 4],    8,  "new"),   # only ~5 weeks history
    ("V125", "Brightwater Spring Water",  "Beverages", [2],       15, "new"),
]

PROFILE = {   # p_late, p_resched, p_noshow, mean late minutes when late, arrival noise (min)
    "reliable":   dict(late=0.08, resched=0.02, noshow=0.01, late_min=35, noise=12),
    "average":    dict(late=0.20, resched=0.05, noshow=0.02, late_min=50, noise=20),
    "unreliable": dict(late=0.38, resched=0.10, noshow=0.04, late_min=70, noise=28),
    "erratic":    dict(late=0.28, resched=0.14, noshow=0.07, late_min=85, noise=40),
    "new":        dict(late=0.25, resched=0.06, noshow=0.03, late_min=55, noise=25),
}

HOLIDAYS = pd.to_datetime([
    "2025-05-26", "2025-07-04", "2025-09-01", "2025-11-27", "2025-12-25",
    "2026-01-01", "2026-05-25", "2026-07-03", "2026-09-07", "2026-11-26",
    "2026-12-25",
])

def near_holiday(d):
    return int(any(abs((d - h).days) <= 3 for h in HOLIDAYS))

vend_rows, rows = [], []
for vid, name, cat, days, win, prof in VENDORS:
    p = PROFILE[prof]
    # each vendor has its own "real" habit: they tend to arrive X minutes off the agreed time
    habit_offset = RNG.normal(20 if prof != "reliable" else 5, 20)
    # ...and each weekday route is different (e.g., Tuesday stop order differs from Friday)
    day_habit = {dd: habit_offset + RNG.normal(0, 25) for dd in days}
    # one "bad" weekday per vendor (e.g., a Monday route that always runs late)
    bad_day = RNG.choice(days) if prof in ("average", "unreliable", "erratic") else None
    start = TODAY - pd.Timedelta(days=24) if prof == "new" else START
    vend_rows.append(dict(vendor_id=vid, vendor_name=name, category=cat,
                          delivery_days=",".join(DOW[d] for d in days),
                          window_start_hour=win, window_minutes=120,
                          onboarded=start.date(), profile_hidden=prof))
    d = start
    while d < TODAY + pd.Timedelta(days=7):
        if d.weekday() in days:
            future = d >= TODAY
            hol = near_holiday(d)
            winter = int(d.month in (12, 1, 2))
            mult = 1.0 + 1.5 * (d.weekday() == bad_day) + 0.6 * hol + 0.4 * winter
            r = RNG.random()
            pn, pr, pl = p["noshow"] * (1 + hol), p["resched"] * (1 + 0.8 * hol), min(p["late"] * mult, 0.85)
            if r < pn:
                status, offset = "No-show", np.nan
            elif r < pn + pr:
                status, offset = "Rescheduled", np.nan
            else:
                base = day_habit[d.weekday()] + RNG.normal(0, p["noise"])
                if RNG.random() < pl:
                    base += RNG.exponential(p["late_min"]) + 30
                offset = round(base)
                status = "Late" if offset > 120 else "On-time"     # late = after the 2-hour agreed window
            variance = int(status in ("On-time", "Late") and RNG.random() < (0.05 if prof == "reliable" else 0.12 if prof in ("average", "new") else 0.2))
            rows.append(dict(vendor_id=vid, date=d.date(), dow=DOW[d.weekday()],
                             window_start_hour=win, holiday_week=hol, winter=winter,
                             status=None if future else status,
                             arrival_offset_min=None if future else offset,
                             count_variance=None if future else variance,
                             is_future=int(future)))
        d += pd.Timedelta(days=1)

pd.DataFrame(vend_rows).to_csv(OUT / "vendors.csv", index=False)
df = pd.DataFrame(rows)
df.to_csv(OUT / "deliveries.csv", index=False)
print(f"vendors={len(vend_rows)}  deliveries(history)={int((df.is_future == 0).sum())}  scheduled(next 7 days)={int(df.is_future.sum())}")
print(df[df.is_future == 0].status.value_counts(normalize=True).round(3))
