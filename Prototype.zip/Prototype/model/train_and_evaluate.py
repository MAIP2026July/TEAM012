"""
VendorPulse AI - Step 2: Train the prediction models, compare with simple baselines,
score vendors, and export everything the copilot app needs (app_data.json).

Three ML outputs (the LLM never calculates these - it only explains them):
  1. Arrival-time prediction   -> predicted arrival window for each scheduled delivery
  2. Late-arrival risk         -> P(vendor arrives after the agreed 2-hour window)
  3. Reschedule/no-show risk   -> P(vendor reschedules or skips the delivery)
Plus a rule-based Vendor Reliability Score (0-100) - transparent on purpose.

Train on history before 2026-06-01, test on 2026-06-01 .. 2026-11-05 (time-based split,
so the model is always judged on "future" deliveries it has not seen).
"""
import json
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import roc_auc_score, average_precision_score, precision_score, recall_score

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
TODAY = pd.Timestamp("2026-11-06")
SPLIT = pd.Timestamp("2026-06-01")
MIN_HISTORY = 8          # fewer prior deliveries than this -> "not enough data"
HIGH, MED = 0.35, 0.18   # risk band thresholds on P(late or disrupted)

vendors = pd.read_csv(DATA / "vendors.csv")
df = pd.read_csv(DATA / "deliveries.csv", parse_dates=["date"]).sort_values(["vendor_id", "date"]).reset_index(drop=True)

# ---------------------------------------------------------------- features
# Every feature is computed ONLY from deliveries before the row's date (no leakage).
def build_features(df):
    feats = []
    for vid, g in df.groupby("vendor_id"):
        hist = []                                   # completed deliveries seen so far
        for _, r in g.iterrows():
            h = pd.DataFrame(hist)
            if len(h):
                last90 = h[h.date >= r.date - pd.Timedelta(days=90)]
                same = h[h.dow == r.dow].tail(8)
                arrived = h[h.status.isin(["On-time", "Late"])]
                arr_same = same[same.status.isin(["On-time", "Late"])]
                f = dict(
                    n_hist=len(h),
                    late_rate_90=(last90.status == "Late").mean() if len(last90) else 0,
                    disrupt_rate_90=last90.status.isin(["Rescheduled", "No-show"]).mean() if len(last90) else 0,
                    dow_late_rate=(same.status == "Late").mean(),
                    dow_disrupt_rate=same.status.isin(["Rescheduled", "No-show"]).mean(),
                    med_offset_10=arrived.arrival_offset_min.tail(10).median() if len(arrived) else 0,
                    dow_med_offset=arr_same.arrival_offset_min.median() if len(arr_same) else (arrived.arrival_offset_min.tail(10).median() if len(arrived) else 0),
                    offset_spread=arrived.arrival_offset_min.tail(20).std() if len(arrived) > 2 else 40,
                    n_same_dow=len(same),
                )
            else:
                f = dict(n_hist=0, late_rate_90=0, disrupt_rate_90=0, dow_late_rate=0, dow_disrupt_rate=0,
                         med_offset_10=0, dow_med_offset=0, offset_spread=40, n_same_dow=0)
            f.update(idx=r.name)
            feats.append(f)
            if not r.is_future:
                hist.append(dict(date=r.date, dow=r.dow, status=r.status, arrival_offset_min=r.arrival_offset_min))
    return pd.DataFrame(feats).set_index("idx")

F = build_features(df)
df = df.join(F)
X_COLS = ["late_rate_90", "disrupt_rate_90", "dow_late_rate", "dow_disrupt_rate", "med_offset_10",
          "dow_med_offset", "offset_spread", "holiday_week", "winter", "window_start_hour"]

df["y_late"] = (df.status == "Late").astype(int)
df["y_disrupt"] = df.status.isin(["Rescheduled", "No-show"]).astype(int)
df["y_any"] = ((df.y_late + df.y_disrupt) > 0).astype(int)

hist = df[(df.is_future == 0) & (df.n_hist >= MIN_HISTORY)]
train, test = hist[hist.date < SPLIT], hist[hist.date >= SPLIT]

# ---------------------------------------------------------------- classifiers
results = {}
models = {}
for target, base_col in [("y_late", "late_rate_90"), ("y_disrupt", "disrupt_rate_90")]:
    lr = LogisticRegression(max_iter=2000, C=0.5).fit(train[X_COLS], train[target])
    gb = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, random_state=0).fit(train[X_COLS], train[target])
    y = test[target]
    out = {"positives_in_test": int(y.sum()), "test_rows": int(len(y))}
    for name, p in [("baseline_vendor_rate", test[base_col]),
                    ("logistic_regression", lr.predict_proba(test[X_COLS])[:, 1]),
                    ("gradient_boosting", gb.predict_proba(test[X_COLS])[:, 1])]:
        out[name] = dict(roc_auc=round(roc_auc_score(y, p), 3), pr_auc=round(average_precision_score(y, p), 3))
    results[target] = out
    models[target] = lr          # chosen: logistic regression (comparable accuracy, explainable weights)

# combined "risk band" evaluation (what the store actually sees: High / Medium / Low)
p_late_t = models["y_late"].predict_proba(test[X_COLS])[:, 1]
p_dis_t = models["y_disrupt"].predict_proba(test[X_COLS])[:, 1]
p_any_t = 1 - (1 - p_late_t) * (1 - p_dis_t)
# fair comparison: both methods flag the same share (top 20%) of deliveries as "high risk"
TOP = 0.20
flag = (p_any_t >= np.quantile(p_any_t, 1 - TOP)).astype(int)
base_score = test.late_rate_90 + test.disrupt_rate_90
base_flag = (base_score >= np.quantile(base_score, 1 - TOP)).astype(int)
results["high_risk_flag"] = {
    "model": dict(precision=round(precision_score(test.y_any, flag), 3), recall=round(recall_score(test.y_any, flag), 3), flagged_share=round(flag.mean(), 3)),
    "baseline_vendor_rate": dict(precision=round(precision_score(test.y_any, base_flag), 3), recall=round(recall_score(test.y_any, base_flag), 3), flagged_share=round(base_flag.mean(), 3)),
    "actual_problem_rate": round(test.y_any.mean(), 3),
}
results["high_risk_flag"]["band_actual_problem_rate"] = {
    band: round(test.y_any[m].mean(), 3) for band, m in
    [("High", p_any_t >= HIGH), ("Medium", (p_any_t >= MED) & (p_any_t < HIGH)), ("Low", p_any_t < MED)]}

# ---------------------------------------------------------------- arrival time
arr_train = train[train.status.isin(["On-time", "Late"])]
arr_test = test[test.status.isin(["On-time", "Late"])]
reg = HistGradientBoostingRegressor(loss="absolute_error", max_depth=3, learning_rate=0.05, max_iter=300, random_state=0)
reg.fit(arr_train[X_COLS], arr_train.arrival_offset_min)
err_model = (arr_test.arrival_offset_min - reg.predict(arr_test[X_COLS])).abs()
err_agreed = arr_test.arrival_offset_min.abs()                         # "vendor comes at agreed time"
err_median = (arr_test.arrival_offset_min - arr_test.med_offset_10).abs()  # simple dashboard average
results["arrival"] = {
    "test_arrivals": int(len(arr_test)),
    "within_45_min": {"agreed_window_rule": round((err_agreed <= 45).mean(), 3),
                      "vendor_recent_median": round((err_median <= 45).mean(), 3),
                      "ml_model": round((err_model <= 45).mean(), 3)},
    "mean_abs_error_min": {"agreed_window_rule": round(err_agreed.mean(), 1),
                           "vendor_recent_median": round(err_median.mean(), 1),
                           "ml_model": round(err_model.mean(), 1)},
}
results["split"] = dict(train=f"{train.date.min().date()} to {train.date.max().date()} ({len(train)} rows)",
                        test=f"{test.date.min().date()} to {test.date.max().date()} ({len(test)} rows)")
results["logistic_weights_late"] = dict(zip(X_COLS, np.round(models["y_late"].coef_[0], 3)))

# ---------------------------------------------------------------- reliability score
def reliability(vid):
    h = df[(df.vendor_id == vid) & (df.is_future == 0) & (df.date >= TODAY - pd.Timedelta(days=90))]
    n = len(h)
    if n < MIN_HISTORY:
        return dict(score=None, n90=n, confidence="Insufficient", components=None)
    arrived = h[h.status.isin(["On-time", "Late"])]
    on_time = (h.status == "On-time").mean()
    resched = (h.status == "Rescheduled").mean()
    noshow = (h.status == "No-show").mean()
    var = arrived.count_variance.mean() if len(arrived) else 0
    score = 100 * (0.40 * on_time + 0.25 * (1 - resched * 4) + 0.20 * (1 - noshow * 5) + 0.15 * (1 - var * 3))
    score = int(round(max(0, min(100, score))))
    return dict(score=score, n90=n, confidence="High" if n >= 20 else "Medium",
                components=dict(on_time_rate=round(on_time, 3), reschedule_rate=round(resched, 3),
                                no_show_rate=round(noshow, 3), variance_rate=round(var, 3)))

# ---------------------------------------------------------------- export for the app
def to_clock(start_hour, offset_min):
    """agreed window start hour + offset in minutes -> 'HH:MM'"""
    t = int(round(start_hour * 60 + offset_min))
    return f"{(t // 60) % 24:02d}:{t % 60:02d}"

future = df[df.is_future == 1].copy()
vend_out, sched_out = [], []
for _, v in vendors.iterrows():
    vid = v.vendor_id
    rel = reliability(vid)
    h = df[(df.vendor_id == vid) & (df.is_future == 0)]
    h90 = h[h.date >= TODAY - pd.Timedelta(days=90)]
    vend_out.append(dict(
        id=vid, name=v.vendor_name, category=v.category, days=v.delivery_days,
        window=f"{v.window_start_hour:02d}:00-{v.window_start_hour + 2:02d}:00",
        total_history=len(h), **rel,
        history90=[dict(date=str(r.date.date()), dow=r.dow, status=r.status,
                        offset=None if pd.isna(r.arrival_offset_min) else int(r.arrival_offset_min),
                        arrived=None if pd.isna(r.arrival_offset_min) else to_clock(v.window_start_hour, r.arrival_offset_min)) for _, r in h90.iterrows()]))

for _, r in future.iterrows():
    v = vendors[vendors.vendor_id == r.vendor_id].iloc[0]
    x = r[X_COLS].to_frame().T.astype(float)
    insufficient = r.n_hist < MIN_HISTORY
    item = dict(vendor_id=r.vendor_id, date=str(r.date.date()), dow=r.dow,
                agreed_window=f"{v.window_start_hour:02d}:00-{v.window_start_hour + 2:02d}:00",
                n_history=int(r.n_hist), insufficient=bool(insufficient))
    if not insufficient:
        pl = float(models["y_late"].predict_proba(x)[0, 1]); pdis = float(models["y_disrupt"].predict_proba(x)[0, 1])
        pany = 1 - (1 - pl) * (1 - pdis)
        off = float(reg.predict(x)[0])
        same = df[(df.vendor_id == r.vendor_id) & (df.is_future == 0) & (df.dow == r.dow)].tail(8)
        late_n = int((same.status == "Late").sum()); dis_n = int(same.status.isin(["Rescheduled", "No-show"]).sum())
        arr = same[same.status.isin(["On-time", "Late"])]
        reasons = [f"Late on {late_n} of the last {len(same)} {r.dow} deliveries",
                   f"Rescheduled or skipped {dis_n} of the last {len(same)} {r.dow} deliveries"]
        if len(arr):
            reasons.append(f"Typical {r.dow} arrival: {to_clock(v.window_start_hour, arr.arrival_offset_min.median())} (agreed window starts {v.window_start_hour:02d}:00)")
        if r.holiday_week:
            reasons.append("Holiday week - deliveries near holidays run later and reschedule more often")
        conf = "High" if r.n_same_dow >= 8 and r.offset_spread < 45 else "Medium" if r.n_same_dow >= 5 else "Low"
        item.update(p_late=round(pl, 2), p_disrupt=round(pdis, 2), p_any=round(pany, 2),
                    risk="High" if pany >= HIGH else "Medium" if pany >= MED else "Low",
                    pred_arrival=to_clock(v.window_start_hour, off),
                    pred_window=f"{to_clock(v.window_start_hour, off - 45)}-{to_clock(v.window_start_hour, off + 45)}",
                    confidence=conf, reasons=reasons)
    sched_out.append(item)

app = dict(meta=dict(store="Pilot Store #101 (simulated)", today=str(TODAY.date()), today_dow="Fri",
                     data_note="All data is simulated for the course prototype. No real vendor or retailer data is used.",
                     thresholds=dict(high=HIGH, medium=MED, min_history=MIN_HISTORY)),
           metrics=results, vendors=vend_out, schedule=sched_out)
(BASE / "app").mkdir(exist_ok=True)
(BASE / "app" / "app_data.json").write_text(json.dumps(app, indent=1, default=float))
(BASE / "model" / "evaluation_results.json").write_text(json.dumps(results, indent=2, default=float))
print(json.dumps(results, indent=2, default=float))
print("today:", [(s["vendor_id"], s.get("risk"), s.get("pred_window")) for s in sched_out if s["date"] == str(TODAY.date())])
